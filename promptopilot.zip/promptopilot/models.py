# promptopilot/models.py

from django.db import models
from django.contrib.auth.models import User

class AdPrompt(models.Model):
    """
    Stores each prompt submitted by a user for the Ad Builder tool.
    """

    TOOL_CHOICES = [
        ("ad_builder", "Ad Builder"),
        # Future tools can be added here (e.g. "blog_writer", "caption_generator")
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="ad_prompts")
    tool = models.CharField(max_length=50, choices=TOOL_CHOICES, default="ad_builder")
    prompt_text = models.TextField(help_text="The prompt submitted to the AI.")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.tool} - {self.created_at.strftime('%Y-%m-%d %H:%M:%S')}"


class AdResult(models.Model):
    """
    Stores the AI-generated result from the prompt.
    """

    prompt = models.OneToOneField(AdPrompt, on_delete=models.CASCADE, related_name="result")
    output_text = models.TextField(help_text="The AI-generated content.")
    model_used = models.CharField(max_length=50, default="gpt-4o")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Output for {self.prompt.tool} at {self.created_at.strftime('%Y-%m-%d %H:%M:%S')}"

from django.db import models

class PromptHistory(models.Model):
    user_id = models.CharField(max_length=100)
    product_name = models.CharField(max_length=255)
    audience = models.TextField()
    tone = models.CharField(max_length=100)
    model_used = models.CharField(max_length=50)
    result = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user_id} - {self.product_name} - {self.created_at.strftime('%Y-%m-%d %H:%M')}"
