from django.apps import AppConfig


class ContentStrategyGeneratorAgenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = "content_strategy_generator_agent"
