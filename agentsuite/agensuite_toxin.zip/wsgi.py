# /path/to/your/agentsuite/wsgi.py
import os
from django.core.wsgi import get_wsgi_application

# Point to your Django settings module
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "agentsuite.settings")

# No secrets or app config here. Keep WSGI minimal.
application = get_wsgi_application()
