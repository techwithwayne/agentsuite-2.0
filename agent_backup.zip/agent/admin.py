from django.contrib import admin
from .models import Conversation

admin.site.register(Conversation)