const greetings = [
  "Hey, I'm Shirley—sorry your website's giving you trouble. Let's sort it out together. What can I do for you today?"
];

function getRandomGreeting() {
  return greetings[Math.floor(Math.random() * greetings.length)];
}

function sendHeight() {
  // Try to find a wrapper element; fallback to individual elements
  const chatWidget = document.getElementById('chat-widget') || document.body;
  let height = chatWidget.scrollHeight;

  // If no wrapper, sum heights of chat-body, chat-input, and form-section
  if (!document.getElementById('chat-widget')) {
    const chatBody = document.getElementById('chat-body');
    const chatInput = document.getElementById('chat-input');
    const formSection = document.getElementById('form-section');
    height = 0;
    if (chatBody) height += chatBody.scrollHeight;
    if (chatInput) height += chatInput.scrollHeight;
    if (formSection && formSection.style.display !== 'none') height += formSection.scrollHeight;
  }

  height += 70; // Extra padding to ensure input area is visible
  window.parent.postMessage({ height: height }, 'https://showcase.techwithwayne.com/'); // Replace with parent origin
  console.log('Sent height to parent:', height); // Debug log
}

document.addEventListener("DOMContentLoaded", () => {
  const userLang = navigator.language.split("-")[0];
  const langSelector = document.getElementById("language-select");

  if (langSelector) {
    langSelector.value = ["en", "es", "fr"].includes(userLang) ? userLang : "en";
  }

  const formSection = document.getElementById("form-section");
  if (formSection) {
    formSection.style.display = "none";
  }

  setTimeout(() => {
    const chatBody = document.getElementById("chat-body");
    if (!chatBody) {
      console.warn("chat-body not found. Skipping greeting injection.");
      return;
    }

    const greeting = getRandomGreeting();
    chatBody.innerHTML += `
      <div class="chat-bubble bot">
        <strong>Shirley:</strong> ${greeting}
      </div>
    `;
    console.log("Greeting injected:", greeting);
    sendHeight();
    document.dispatchEvent(new Event('chatUpdated'));
  }, 100);

  // Set up ResizeObserver
  const observer = new ResizeObserver(() => {
    sendHeight();
  });
  const chatWidget = document.getElementById('chat-widget') || document.getElementById('chat-body') || document.body;
  observer.observe(chatWidget);
});

async function sendMessage() {
  const input = document.getElementById("user-input");
  const chatBody = document.getElementById("chat-body");

  if (!input || !chatBody) {
    console.warn("Chat elements not found. Cannot send message.");
    return;
  }

  const message = input.value.trim();
  if (!message) return;

  const now = new Date();
  const timestamp = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  chatBody.innerHTML += `
    <div class="chat-bubble user">
      ${message}
      <div class="timestamp">${timestamp}</div>
    </div>
  `;
  input.value = "";
  chatBody.scrollTop = chatBody.scrollHeight;
  sendHeight();
  document.dispatchEvent(new Event('chatUpdated'));

  const typingDiv = document.createElement("div");
  typingDiv.className = "typing-bubble";
  typingDiv.innerHTML = "Shirley is typing...";
  chatBody.appendChild(typingDiv);
  chatBody.scrollTop = chatBody.scrollHeight;

  try {
    const response = await fetch("/webdoctor/handle_message/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();
    typingDiv.remove();

    const botTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    chatBody.innerHTML += `
      <div class="chat-bubble bot">
        ${data.response}
        <div class="timestamp">${botTime}</div>
      </div>
    `;
    chatBody.scrollTop = chatBody.scrollHeight;
    sendHeight();
    document.dispatchEvent(new Event('chatUpdated'));

    if (String(data.stage).trim() === "offered_report") {
      const chatInput = document.getElementById("chat-input");
      if (chatInput) {
        chatInput.style.display = "none";
      }
      const formSection = document.getElementById("form-section");
      if (formSection) {
        formSection.style.display = "flex";
      }
      sendHeight();
      document.dispatchEvent(new Event('chatUpdated'));
    }
  } catch (error) {
    typingDiv.remove();
    chatBody.innerHTML += `<div class="chat-bubble bot">Oops! Something went wrong.</div>`;
    console.error("Error in sendMessage:", error);
    sendHeight();
    document.dispatchEvent(new Event('chatUpdated'));
  }
}

async function submitForm() {
  const nameEl = document.getElementById("form-name");
  const emailEl = document.getElementById("form-email");
  const inputEl = document.getElementById("user-input");

  if (!nameEl || !emailEl) {
    console.warn("Form elements not found. Cannot submit form.");
    return;
  }

  const name = nameEl.value;
  const email = emailEl.value;
  const issue = (inputEl ? inputEl.value : "") || "General issue";

  try {
    const response = await fetch("/webdoctor/submit_form/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, issue }),
    });

    const data = await response.json();
    const chatBody = document.getElementById("chat-body");

    if (!chatBody) {
      console.warn("chat-body not found. Cannot update chat after form submission.");
      return;
    }

    const formSection = document.getElementById("form-section");
    if (formSection) {
      formSection.style.display = "none";
    }
    const chatInput = document.getElementById("chat-input");
    if (chatInput) {
      chatInput.style.display = "flex";
    }

    chatBody.innerHTML += `
      <div class="chat-bubble bot">
        <strong>Shirley:</strong> Your report has been sent. Here are some options if you need more help:
      </div>
    `;

    const ctaContainer = document.createElement("div");
    ctaContainer.style.display = "flex";
    ctaContainer.style.gap = "10px";
    ctaContainer.style.marginTop = "10px";
    ctaContainer.style.flexWrap = "wrap";

    const siteReviewBtn = document.createElement("a");
    siteReviewBtn.href = "https://techwithwayne.com/free-site-review";
    siteReviewBtn.target = "_blank";
    siteReviewBtn.className = "cta-button";
    Facet: siteReviewBtn.textContent = "Free Site Review";

    const consultBtn = document.createElement("a");
    consultBtn.href = "https://techwithwayne.com/free-consultation";
    consultBtn.target = "_blank";
    consultBtn.className = "cta-button";
    consultBtn.textContent = "Free Consultation";

    ctaContainer.appendChild(siteReviewBtn);
    ctaContainer.appendChild(consultBtn);
    chatBody.appendChild(ctaContainer);

    chatBody.scrollTop = chatBody.scrollHeight;
    sendHeight();
    document.dispatchEvent(new Event('chatUpdated'));
  } catch (err) {
    console.error("Error in submitForm:", err);
    const chatBody = document.getElementById("chat-body");
    if (chatBody) {
      chatBody.innerHTML += `<div class="chat-bubble bot"><strong>Shirley:</strong> Sorry, there was an issue submitting your request.</div>`;
      sendHeight();
      document.dispatchEvent(new Event('chatUpdated'));
    }
  }
}

window.sendMessage = sendMessage;
window.submitForm = submitForm;