from django.apps import AppConfig

class WebdoctorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'webdoctor'
    verbose_name = "WebDoctor AI Support"
