"""therapylib.models.adverse_effect"""

