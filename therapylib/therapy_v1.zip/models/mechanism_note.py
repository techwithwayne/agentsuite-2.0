"""therapylib.models.mechanism_note"""

