"""therapylib.models.interaction_rule"""

