"""therapylib.models.drug"""

