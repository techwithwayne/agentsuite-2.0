"""therapylib.models.interaction_signal"""

