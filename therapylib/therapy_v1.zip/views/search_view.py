from django.db.models import Q
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from therapylib.models import Monograph, Protocol
from therapylib.serializers.monograph import MonographSerializer
from therapylib.serializers.protocol import ProtocolSerializer


class SearchView(APIView):
    """
    GET /api/therapylib/search?q=term
    Returns monographs and latest-published protocol per condition that match the query.
    """
    def get(self, request, *args, **kwargs):
        q = (request.GET.get("q") or "").strip()
        if not q:
            return Response({"q": "", "monographs": [], "protocols": []}, status=status.HTTP_200_OK)

        # Monographs
        monographs_qs = (
            Monograph.objects
            .filter(Q(substance__name__icontains=q) | Q(substance__slug__icontains=q))
            .select_related("substance", "current_version", "substance__category")
            .prefetch_related("current_version__doses__form", "current_version__references")
        )[:10]
        monographs = list(monographs_qs)

        # Protocols (match by condition or items' substance); reduce to latest per condition (DB-agnostic)
        prot_qs = (
            Protocol.objects
            .filter(published=True)
            .filter(
                Q(condition__name__icontains=q) |
                Q(condition__slug__icontains=q) |
                Q(items__substance__name__icontains=q) |
                Q(items__substance__slug__icontains=q)
            )
            .select_related("condition")
            .prefetch_related("items__substance", "items__preparation_form", "items__evidence", "references")
        )
        latest_by_condition = {}
        for p in prot_qs:
            cur = latest_by_condition.get(p.condition_id)
            if cur is None or p.version > cur.version:
                latest_by_condition[p.condition_id] = p
        protocols = list(latest_by_condition.values())[:10]

        return Response({
            "q": q,
            "monographs": MonographSerializer(monographs, many=True).data,
            "protocols":  ProtocolSerializer(protocols, many=True).data,
        }, status=status.HTTP_200_OK)
