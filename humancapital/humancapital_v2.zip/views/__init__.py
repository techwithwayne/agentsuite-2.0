from .assessment_views import welcome, personal_info
from .skills_views import skills_form
from .cognitive_views import cognitive_form
from .personality_views import personality_form
from .behavior_views import behavior_form
from .motivation_views import motivation_form
from .summary_views import summary_view


