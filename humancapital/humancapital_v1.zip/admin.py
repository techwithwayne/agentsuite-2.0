from django.contrib import admin
from .models import (
    UserProfile,
    AssessmentSession,
    Skill,
    CognitiveAbility,
    Personality,
    Behavior,
    Motivation,
    Response,
    Scorecard,
)


# Register each model so it appears in Django Admin under "Human Capital"
@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("full_name", "email", "job_title", "industry", "created_at")
    search_fields = ("full_name", "email", "job_title", "industry")


@admin.register(AssessmentSession)
class AssessmentSessionAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "started_at", "completed_at", "is_completed")
    list_filter = ("is_completed", "started_at")


@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = ("session", "category", "name", "rating", "weight")
    list_filter = ("category",)


@admin.register(CognitiveAbility)
class CognitiveAbilityAdmin(admin.ModelAdmin):
    list_display = ("session", "reasoning", "memory", "problem_solving", "attention")
    search_fields = ("session__user__full_name",)


@admin.register(Personality)
class PersonalityAdmin(admin.ModelAdmin):
    list_display = ("session", "openness", "conscientiousness", "extraversion", "agreeableness", "neuroticism")
    search_fields = ("session__user__full_name",)


@admin.register(Behavior)
class BehaviorAdmin(admin.ModelAdmin):
    list_display = ("session", "communication", "decision_making", "leadership", "collaboration", "conflict_handling")


@admin.register(Motivation)
class MotivationAdmin(admin.ModelAdmin):
    list_display = ("session", "achievement", "stability", "autonomy", "recognition", "learning")


@admin.register(Response)
class ResponseAdmin(admin.ModelAdmin):
    list_display = ("session", "question_type", "question_text", "answer_text", "answer_value", "response_time")
    list_filter = ("question_type",)


@admin.register(Scorecard)
class ScorecardAdmin(admin.ModelAdmin):
    list_display = ("session", "skill_index", "cognitive_index", "personality_index", "behavior_index", "motivation_index")
