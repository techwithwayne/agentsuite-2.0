from .personal_info_form import PersonalInfoForm
from .skill_form import SkillForm
from .cognitive_form import CognitiveForm
from .personality_form import PersonalityForm
from .behavior_form import BehaviorForm
from .motivation_form import MotivationForm

