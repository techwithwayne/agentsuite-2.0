from django.db import models
from .user_profile import UserProfile


class AssessmentSession(models.Model):
    """
    Represents a single assessment attempt by a user.
    Ties together all parts: skills, cognitive, personality, etc.
    """

    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name="sessions")
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    is_completed = models.BooleanField(default=False)
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"Session #{self.id} for {self.user.full_name}"
