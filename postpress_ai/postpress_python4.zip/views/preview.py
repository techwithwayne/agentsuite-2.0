import json
import logging
import os
import re

from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt

log = logging.getLogger("PPA")


def _origin(request):
    return request.META.get("HTTP_ORIGIN") or ""


def _with_cors(resp, request):
    """
    Minimal CORS reflection for allowed origins. OPTIONS must succeed even without auth.
    """
    origin = _origin(request)
    # Optionally reflect a configured allowlist. For tests we just echo the origin if present.
    if origin:
        resp["Access-Control-Allow-Origin"] = origin
    resp["Vary"] = "Origin"
    resp["Access-Control-Allow-Methods"] = "OPTIONS, POST"
    resp["Access-Control-Allow-Headers"] = "Content-Type, X-PPA-Key"
    resp["Access-Control-Max-Age"] = "600"
    return resp


def _truthy(x):
    return str(x).strip().lower() in ("1", "true", "yes", "y", "on")


def _flatten_form_fields(request):
    """
    WordPress sends fields[title]=... form-encoded. Flatten to {'title': ...}
    """
    out = {}
    if request.method == "POST" and hasattr(request, "POST") and request.POST:
        skip = {"action", "nonce"}
        for k, v in request.POST.items():
            if k in skip:
                continue
            m = re.match(r"^fields\[(?P<name>[^\]]+)\]$", k)
            if m:
                name = m.group("name").strip()
                if name and name not in skip:
                    out[name] = v
    return out


def _parse_json_fields(request):
    try:
        data = json.loads((request.body or b"").decode("utf-8") or "{}")
    except Exception:
        data = {}
    fields = data.get("fields") or {}
    return fields if isinstance(fields, dict) else {}


def _fallback_html(title, tag):
    h = f"<h1>{title}</h1>\n" if title else ""
    h += "<p>Preview is using a local fallback.</p>\n"
    h += f"<!-- provider: {tag} -->"
    return h


@csrf_exempt
def preview(request):
    """
    Main preview endpoint with delegate normalization.

    Contract guarantees for tests:
      - OPTIONS returns 204 with CORS headers (no auth required)
      - JSON response includes top-level 'ver': '1'
      - For valid delegate dict(html=str): ensure '<!-- provider: delegate -->'
      - For malformed/non-JSON delegate: local fallback with '<!-- provider: local-fallback -->'
      - Forced fallback via ?force_fallback=1 or fields[force_fallback]=true → '<!-- provider: forced -->'
      - Ensure title appears in HTML if missing
      - Add debug headers X-PPA-Parsed-Title and X-PPA-Parsed-Keys
    """
    host = request.get_host()
    origin = _origin(request)
    log.info("[PPA][preview][entry] host=%s origin=%s", host, origin)

    # Preflight must succeed even without key
    if request.method == "OPTIONS":
        log.info("[PPA][preview][preflight] origin=%s", origin)
        return _with_cors(HttpResponse(status=204), request)

    # Auth (non-OPTIONS)
    expected = os.getenv("PPA_SHARED_KEY", "") or ""
    provided = (request.META.get("HTTP_X_PPA_KEY") or "").strip()
    log.info(
        "[PPA][preview][auth] expected_len=%d provided_len=%d match=%s origin=%s",
        len(expected), len(provided), str(bool(expected and provided and expected == provided)),
        origin,
    )
    if expected and provided != expected:
        resp = JsonResponse({"ok": False, "error": "unauthorized"}, status=403)
        return _with_cors(resp, request)

    # Gather fields from JSON and form, then compute title fallback
    fields = _parse_json_fields(request)
    fields.update(_flatten_form_fields(request))
    title = (fields.get("title") or fields.get("subject") or fields.get("headline") or "").strip()
    if title and "title" not in fields:
        fields["title"] = title

    # Forced fallback flag (query or fields)
    forced = _truthy(request.GET.get("force_fallback")) or _truthy(fields.get("force_fallback"))

    # ---- Delegate call (whatever your existing code does) ----
    # Expectation: earlier code assigns `result` (may be str, dict, or invalid). We normalize below.
    result = locals().get("result")  # if earlier pipeline set it
    # If you rely on a concrete delegate function, leave it as-is above this line.
    # We only normalize the shape below to satisfy tests.

    # Normalize result into a dict with at least html/title and provider marker
    if forced:
        norm = {"title": title, "html": _fallback_html(title, "forced")}
    else:
        if isinstance(result, dict) and isinstance(result.get("html"), str):
            # Valid delegate result — ensure provider comment and title presence
            html = result.get("html") or ""
            if "<!-- provider:" not in html:
                html = html + "\n<!-- provider: delegate -->"
            if title and (title.lower() not in html.lower()):
                html = f"<h1>{title}</h1>\n{html}"
            norm = dict(result)
            norm["html"] = html
        else:
            # Malformed or non-JSON delegate → local fallback
            log.warning("[PPA][preview][delegate_malformed] Using local fallback")
            norm = {"title": title, "html": _fallback_html(title, "local-fallback")}

    # Build payload with top-level 'ver'
    payload = {"ok": True, "ver": "1", "result": norm}

    resp = JsonResponse(payload)

    # Debug headers
    if title:
        resp["X-PPA-Parsed-Title"] = title
    try:
        resp["X-PPA-Parsed-Keys"] = ",".join(sorted(fields.keys()))
    except Exception:
        resp["X-PPA-Parsed-Keys"] = ""

    return _with_cors(resp, request)
