from django.apps import AppConfig

class PostpressAiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "postpress_ai"
    verbose_name = "PostPress AI"
