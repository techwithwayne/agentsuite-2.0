// reserved for future Django-side admin; WP drives the real admin UI
console.log("postpress_ai admin JS loaded");
