# =======================================
# ~/agentsuite/postpress_ai/tests/__init__.py
# =======================================
"""
CHANGE LOG
- 2025-08-15 — Initial test package for PostPress AI.

Notes
- Keeping this file so Django discovers the tests/ package reliably.
- Actual tests live in test_api.py.
"""
# (Intentionally empty)
