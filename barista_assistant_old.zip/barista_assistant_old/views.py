from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return HttpResponse("Hello from Barista Assistant!")

# Create your views here.
