# promptopilot/views.py

from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from .models import PromptHistory
import datetime

# Main iframe-based form interface (GET-only)
def ad_builder_page(request):
    return render(request, "promptopilot/ad_builder.html", {
        "STATIC_HOST": "/static/"
    })

# Clean iframe version if you need it
def widget_frame_page(request):
    return render(request, "promptopilot/widget_frame.html", {
        "STATIC_HOST": "/static/"
    })

# JSON API to handle POST submissions
@csrf_exempt
def ad_builder_api(request):
    if request.method == "POST":
        # 🔍 Debug: Dump the incoming data
        print("🔍 POST DATA:", request.POST)
        print("User ID:", request.POST.get("user_id"))
        print("Product Name:", request.POST.get("product_name"))
        print("Audience:", request.POST.get("audience"))
        print("Tone:", request.POST.get("tone"))
        print("Model:", request.POST.get("model"))

        # 🧠 Simulate AI output for now
        output = f"🚀 Sample ad generated for {request.POST.get('product_name')} targeting {request.POST.get('audience')} with a {request.POST.get('tone')} tone using {request.POST.get('model')}."

        # ✅ Save to PromptHistory
        PromptHistory.objects.create(
            user_id=request.POST.get("user_id", "anonymous"),
            product_name=request.POST.get("product_name", ""),
            audience=request.POST.get("audience", ""),
            tone=request.POST.get("tone", ""),
            model_used=request.POST.get("model", ""),
            result=output
        )

        # ✅ Return JSON response
        return JsonResponse({"result": output})

    return JsonResponse({"error": "Invalid request"}, status=400)

# Optional frontend page to view prompt history
def prompt_history_view(request):
    user_id = request.GET.get("user_id", "anonymous")
    history = PromptHistory.objects.filter(user_id=user_id).order_by("-created_at")[:50]
    return render(request, "promptopilot/prompt_history.html", {
        "history": history,
        "user_id": user_id
    })
