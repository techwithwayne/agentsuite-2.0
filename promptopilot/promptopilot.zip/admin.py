from django.contrib import admin
from .models import PromptHistory

@admin.register(PromptHistory)
class PromptHistoryAdmin(admin.ModelAdmin):
    list_display = ("user_id", "product_name", "tone", "model_used", "created_at")
    search_fields = ("user_id", "product_name", "audience", "tone", "result")
    list_filter = ("model_used", "created_at")
    ordering = ("-created_at",)# Register your models here.
