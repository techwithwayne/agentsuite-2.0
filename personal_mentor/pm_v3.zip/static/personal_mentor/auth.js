(function () {
  const VERSION = "auth.js v2025-08-12-03";
  console.log("%cPersonal Mentor Auth:", "font-weight:bold", VERSION);

  // Elements
  const overlay = document.getElementById("pm-auth-overlay");
  const cardRegister = document.getElementById("pm-auth-register");
  const cardLogin = document.getElementById("pm-auth-login");
  const cardConfirm = document.getElementById("pm-auth-confirm");

  const formRegister = document.getElementById("pm-auth-register-form");
  const formLogin = document.getElementById("pm-auth-login-form");
  const formConfirm = document.getElementById("pm-auth-confirm-form");

  const errRegister = document.getElementById("pm-auth-register-error");
  const errLogin = document.getElementById("pm-auth-login-error");
  const errConfirm = document.getElementById("pm-auth-confirm-error");

  const linkLogin = document.getElementById("pm-link-login");
  const linkRegister = document.getElementById("pm-link-register");
  const btnResend = document.getElementById("pm-resend");

  // Endpoints
  const E_REGISTER = "/personal-mentor/auth/register/";
  const E_CONFIRM = "/personal-mentor/auth/confirm/";
  const E_LOGIN = "/personal-mentor/auth/login/";

  // Gate the chat UI
  const chatForm = document.getElementById("pm-form");
  const chatInput = document.getElementById("pm-input");
  const chatSendBtn = chatForm?.querySelector("button[type='submit']");

  // Always show overlay initially (server enforces too)
  forceOverlay(true);

  // Toggle helpers
  function showCard(which) {
    cardRegister.hidden = which !== "register";
    cardLogin.hidden = which !== "login";
    cardConfirm.hidden = which !== "confirm";
    console.log("[Auth] Showing card:", which);
  }

  // CSRF helper
  function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(";").shift();
  }
  function csrftoken() {
    return getCookie("csrftoken");
  }

  // Fetch wrapper
  async function postForm(url, data) {
    const formData = new FormData();
    Object.entries(data).forEach(([k, v]) => formData.append(k, v));
    const res = await fetch(url, {
      method: "POST",
      headers: { "X-CSRFToken": csrftoken() || "" },
      body: formData,
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || !json.ok) {
      const msg = json.error || `Request failed (${res.status})`;
      throw new Error(msg);
    }
    return json;
  }

  function forceOverlay(on) {
    overlay.setAttribute("aria-hidden", on ? "false" : "true");
    overlay.style.display = on ? "grid" : "none";
    // lock send
    if (chatInput && chatSendBtn) {
      chatInput.disabled = on;
      chatSendBtn.disabled = on;
      chatInput.placeholder = on ? "Create an account to start..." : "Type a message...";
    }
  }

  // Loading state helpers (button text → 'Processing' + spinner)
  function setLoading(btn, on) {
    if (!btn) return;
    if (on) {
      btn.dataset.label = btn.textContent;
      btn.textContent = "Processing";
      btn.classList.add("is-loading");
      btn.disabled = true;
    } else {
      btn.textContent = btn.dataset.label || btn.textContent;
      btn.classList.remove("is-loading");
      btn.disabled = false;
    }
  }

  // Links
  linkLogin.addEventListener("click", (e) => {
    e.preventDefault();
    clearErrors();
    showCard("login");
  });

  linkRegister.addEventListener("click", (e) => {
    e.preventDefault();
    clearErrors();
    showCard("register");
  });

  btnResend?.addEventListener("click", async () => {
    errConfirm.textContent = "To resend, go back and submit Register or Login again. (Resend limited every 2 minutes.)";
  });

  // Forms
  formRegister.addEventListener("submit", async (e) => {
    e.preventDefault();
    errRegister.textContent = "";
    const name = document.getElementById("pm-name").value.trim();
    const email = document.getElementById("pm-email").value.trim();
    const password = document.getElementById("pm-password").value;

    const submitBtn = formRegister.querySelector(".pm-auth-submit");
    try {
      setLoading(submitBtn, true);
      const r = await postForm(E_REGISTER, { name, email, password });
      console.log("[Auth] register result:", r);
      if (r.email_sent === false) {
        console.warn("[Auth] Email NOT sent. Check EMAIL_BACKEND and SMTP env vars on server.");
      }
      if (r.next === "confirm") {
        showCard("confirm");
      }
    } catch (err) {
      console.error("[Auth] register error:", err);
      errRegister.textContent = err.message || "Could not create account.";
    } finally {
      setLoading(submitBtn, false);
    }
  });

  formLogin.addEventListener("submit", async (e) => {
    e.preventDefault();
    errLogin.textContent = "";
    const email = document.getElementById("pm-login-email").value.trim();
    const password = document.getElementById("pm-login-password").value;

    const submitBtn = formLogin.querySelector(".pm-auth-submit");
    try {
      setLoading(submitBtn, true);
      const r = await postForm(E_LOGIN, { email, password });
      console.log("[Auth] login result:", r);
      if (r.email_sent === false) {
        console.warn("[Auth] Email NOT sent on login. Check server email config.");
      }
      if (r.next === "confirm") {
        showCard("confirm");
      } else {
        forceOverlay(false);
      }
    } catch (err) {
      console.error("[Auth] login error:", err);
      errLogin.textContent = err.message || "Could not log in.";
    } finally {
      setLoading(submitBtn, false);
    }
  });

  formConfirm.addEventListener("submit", async (e) => {
    e.preventDefault();
    errConfirm.textContent = "";
    const code = document.getElementById("pm-code").value.trim();

    const submitBtn = formConfirm.querySelector(".pm-auth-submit");
    try {
      setLoading(submitBtn, true);
      const r = await postForm(E_CONFIRM, { code });
      console.log("[Auth] confirm result:", r);
      forceOverlay(false);
    } catch (err) {
      console.error("[Auth] confirm error:", err);
      errConfirm.textContent = err.message || "Invalid or expired code.";
    } finally {
      setLoading(submitBtn, false);
    }
  });

  // ===== Password reveal (eye) =====
  function bindEyes() {
    const eyes = document.querySelectorAll(".pm-eye");
    eyes.forEach((btn) => {
      const inputId = btn.getAttribute("data-target");
      const input = document.getElementById(inputId);
      if (!input) return;

      btn.addEventListener("click", () => {
        const isText = input.type === "text";
        input.type = isText ? "password" : "text";
        btn.setAttribute("aria-pressed", String(!isText));
        btn.setAttribute("aria-label", isText ? "Show password" : "Hide password");
        btn.title = isText ? "Show password" : "Hide password";
        btn.classList.toggle("is-showing", !isText);
      });

      // Optional: press-and-hold peek
      btn.addEventListener("pointerdown", () => {
        if (input.type === "password") {
          input.type = "text";
          btn.classList.add("is-showing");
          btn.setAttribute("aria-pressed", "true");
        }
      });
      window.addEventListener("pointerup", () => {
        if (btn.classList.contains("is-showing") && input.type === "text") {
          // Only auto-hide if we were showing from press-and-hold and not toggled by click
          // (We won't try to track toggle state complexity; this is a graceful fallback.)
        }
      });
    });
  }
  bindEyes();

  function clearErrors() {
    errRegister.textContent = "";
    errLogin.textContent = "";
    errConfirm.textContent = "";
  }
})();
