from django.http import JsonResponse

class MentorAccessMiddleware:
    API_PREFIXES = ("/personal-mentor/api/",)
    EXEMPT_PATHS = {
        "/personal-mentor/api/health/",  # allow unauthenticated health ping
    }

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path or ""
        if path.startswith(self.API_PREFIXES) and path not in self.EXEMPT_PATHS:
            is_verified = bool(request.session.get("mentor_verified"))
            if not is_verified:
                user = getattr(request, "user", None)
                if user and user.is_authenticated:
                    prof = getattr(user, "mentor_profile", None)
                    if prof and getattr(prof, "verified_at", None):
                        request.session["mentor_verified"] = True
                        is_verified = True
            if not is_verified:
                return JsonResponse(
                    {"ok": False, "error": "Not verified. Please register and confirm email."},
                    status=403
                )
        return self.get_response(request)
