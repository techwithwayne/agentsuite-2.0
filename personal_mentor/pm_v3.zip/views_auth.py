from __future__ import annotations
import re
import logging
from django.conf import settings
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.core.mail import send_mail, EmailMessage
from django.http import JsonResponse, HttpRequest
from django.views.decorators.http import require_POST
from django.utils import timezone

from .models import UserProfile

logger = logging.getLogger(__name__)

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def _json_error(msg: str, status: int = 400) -> JsonResponse:
    return JsonResponse({"ok": False, "error": msg}, status=status)

@require_POST
def start_registration(request: HttpRequest) -> JsonResponse:
    """
    Accepts name, email, password; creates (or reuses) a user and sends a 6-digit code.
    Only the first part of the name (first word) is stored in User.first_name.
    """
    name_input = (request.POST.get("name") or "").strip()
    first_name = name_input.split()[0] if name_input else ""  # Take only the first word

    email = (request.POST.get("email") or "").lower().strip()
    password = (request.POST.get("password") or "")

    if not first_name or not email or not password:
        return _json_error("All fields are required.")

    if not EMAIL_RE.match(email):
        return _json_error("Please enter a valid email address.")

    # Create or reuse user; username as email
    user, created = User.objects.get_or_create(
        username=email,
        defaults={"email": email, "first_name": first_name}
    )

    if not created:
        updated = False
        if user.first_name != first_name:
            user.first_name = first_name
            updated = True
        if user.email != email:
            user.email = email
            updated = True
        if updated:
            user.save(update_fields=["first_name", "email"])

    # Always set password freshly here
    user.set_password(password)
    user.is_active = True  # gating is via verification code + middleware
    user.save()

    prof, _ = UserProfile.objects.get_or_create(user=user)
    code = prof.issue_code()

    subject = "Your Personal Mentor confirmation code"
    message = (
        f"Hi {first_name or 'there'},\n\n"
        f"Your confirmation code is: {code}\n"
        f"It expires in 20 minutes.\n\n"
        f"If you didn’t request this, you can ignore this email."
    )

    email_sent = False
    try:
        # Use send_mail (returns number of successfully delivered messages)
        sent_count = send_mail(
            subject,
            message,
            getattr(settings, "DEFAULT_FROM_EMAIL", "no-reply@example.com"),
            [email],
            fail_silently=False,
        )
        email_sent = sent_count == 1
        print(f"[Auth] Registration code email sent? {email_sent} → {email}")  # server console
        logger.info("Registration email to %s sent=%s backend=%s",
                    email, email_sent, settings.EMAIL_BACKEND)
    except Exception as e:
        print(f"[Auth] FAILED to send registration email to {email}: {e}")
        logger.exception("Failed sending registration email to %s", email)
        email_sent = False

    request.session["pending_email"] = email
    # For dev convenience, include email_sent; safe to ignore on frontend
    return JsonResponse({"ok": True, "next": "confirm", "email_sent": email_sent})

@require_POST
def confirm_code(request: HttpRequest) -> JsonResponse:
    """
    Accepts email and 6-digit code, verifies, logs in, and sets session flag.
    """
    email = (request.POST.get("email") or request.session.get("pending_email") or "").lower().strip()
    code = (request.POST.get("code") or "").strip()

    if not email or not code:
        return _json_error("Email and code are required.")

    try:
        user = User.objects.get(username=email)
    except User.DoesNotExist:
        return _json_error("No account found for that email.")

    try:
        prof = user.mentor_profile
    except UserProfile.DoesNotExist:
        return _json_error("No pending verification for this account.")

    if not prof.code_valid(code):
        return _json_error("Invalid or expired code.")

    # Mark verified
    prof.verified_at = timezone.now()
    prof.verification_code = ""
    prof.save(update_fields=["verified_at", "verification_code"])

    # Log in and set gate flag
    user = authenticate(request, username=email, password=request.POST.get("password") or None)
    if not user:
        # If password wasn't supplied here (normal), force-session login with the account
        user = User.objects.get(username=email)
    login(request, user)
    request.session["mentor_verified"] = True

    # cleanup
    request.session.pop("pending_email", None)
    logger.info("User %s confirmed and logged in", email)

    return JsonResponse({"ok": True})

@require_POST
def login_user(request: HttpRequest) -> JsonResponse:
    email = (request.POST.get("email") or "").lower().strip()
    password = (request.POST.get("password") or "")
    if not email or not password:
        return _json_error("Email and password are required.")

    user = authenticate(request, username=email, password=password)
    if not user:
        return _json_error("Invalid credentials.")

    prof, _ = UserProfile.objects.get_or_create(user=user)
    if prof.needs_verification():
        code = prof.issue_code()
        subject = "Your Personal Mentor confirmation code"
        message = (
            f"Hi {user.first_name or 'there'},\n\n"
            f"Your confirmation code is: {code}\n"
            f"It expires in 20 minutes."
        )

        email_sent = False
        try:
            sent_count = send_mail(
                subject,
                message,
                getattr(settings, "DEFAULT_FROM_EMAIL", "no-reply@example.com"),
                [email],
                fail_silently=False,
            )
            email_sent = sent_count == 1
            print(f"[Auth] Login resend code email sent? {email_sent} → {email}")
            logger.info("Login resend email to %s sent=%s backend=%s",
                        email, email_sent, settings.EMAIL_BACKEND)
        except Exception as e:
            print(f"[Auth] FAILED to send login resend email to {email}: {e}")
            logger.exception("Failed sending login resend email to %s", email)
            email_sent = False

        request.session["pending_email"] = email
        return JsonResponse({"ok": True, "next": "confirm", "email_sent": email_sent})

    login(request, user)
    request.session["mentor_verified"] = True
    logger.info("User %s logged in (already verified)", email)
    return JsonResponse({"ok": True})
